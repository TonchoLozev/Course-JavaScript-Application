function startApp() {
    showMenuLinks();
    showView('viewHome');
    attachAllEvents();
}